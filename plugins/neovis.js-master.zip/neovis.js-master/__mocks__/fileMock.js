export default '__tests__-file-stub';
